(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9d307fc7._.css",
  "static/chunks/a9bf9_@clerk_nextjs_dist_esm_app-router_client_keyless-creator-reader_d05dcfdf.js",
  "static/chunks/node_modules_a53207db._.js",
  "static/chunks/app_SessionProviderWrapper_tsx_5cf5d72b._.js"
],
    source: "dynamic"
});
