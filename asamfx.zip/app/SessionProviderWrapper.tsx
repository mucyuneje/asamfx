// app/SessionProviderWrapper.tsx
"use client";

import { ClerkLoaded, ClerkLoading, SignedIn, SignedOut, RedirectToSignIn } from "@clerk/nextjs";

export default function SessionProviderWrapper({ children }: { children: React.ReactNode }) {
  return (
    <ClerkLoaded>
      <SignedIn>{children}</SignedIn>
      <SignedOut>
        <RedirectToSignIn />
      </SignedOut>
    </ClerkLoaded>
  );
}
