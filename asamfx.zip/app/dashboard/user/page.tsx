"use client";

import { useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function UserDashboardPage() {
  const [activePage, setActivePage] = useState("/dashboard/user");

  const renderContent = () => {
    switch (activePage) {
      case "/dashboard/user":
        return <Card><CardHeader><CardTitle>Welcome!</CardTitle></CardHeader><CardContent>Watch purchased videos here.</CardContent></Card>;
      case "/dashboard/user/my-videos":
        return <Card><CardHeader><CardTitle>My Videos</CardTitle></CardHeader><CardContent>List of purchased videos</CardContent></Card>;
      case "/dashboard/user/payments":
        return <Card><CardHeader><CardTitle>Payments</CardTitle></CardHeader><CardContent>View payments</CardContent></Card>;
      default:
        return <div>Page not found</div>;
    }
  };

  return (
    <div className="flex">
      <Sidebar currentPage={activePage} role="STUDENT" onNavigate={setActivePage} />

      <main className="flex-1 p-6 bg-gray-50 dark:bg-gray-900 overflow-y-auto">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">User Dashboard</h1>
          <div>Plan: Premium</div>
        </header>

        {renderContent()}
      </main>
    </div>
  );
}
