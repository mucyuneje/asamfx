"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sun, Moon, Menu, X, LogOut, User } from "lucide-react";
import { useTheme } from "next-themes";
import { useUser, SignOutButton } from "@clerk/nextjs";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const { isSignedIn, user } = useUser(); // Clerk hook

  // Fix hydration mismatch
  useEffect(() => setMounted(true), []);

  const navLinks = ["Home", "Signals", "Courses", "Mentorship"];
  if (!mounted) return null; // avoid SSR mismatch

  const toggleTheme = () => setTheme(theme === "dark" ? "light" : "dark");

  return (
    <nav className="fixed w-full z-50 bg-background/90 backdrop-blur-md shadow-sm border-b border-border transition-colors duration-500">
      <div className="w-full max-w-7xl 2xl:max-w-[1600px] mx-auto px-6 py-4 flex justify-between items-center">
        <div className="text-2xl font-bold">AsamFXAcademy</div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-6">
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="hover:text-primary transition-colors"
            >
              {link}
            </a>
          ))}

          {isSignedIn ? (
            <>
              <a
                href="/dashboard"
                className="flex items-center px-4 py-2 rounded bg-[color:var(--primary)] text-[color:var(--primary-foreground)] hover:brightness-90 transition"
              >
                <User className="mr-2" /> {user?.firstName || "Account"}
              </a>
              <SignOutButton>
                <button className="flex items-center px-4 py-2 rounded bg-destructive text-destructive-foreground hover:brightness-90 transition">
                  <LogOut className="mr-2" /> Logout
                </button>
              </SignOutButton>
            </>
          ) : (
            <a
              href="/register"
              className="px-4 py-2 rounded transition bg-[color:var(--primary)] text-[color:var(--primary-foreground)] hover:brightness-90"
            >
              Join Now
            </a>
          )}

          <button onClick={toggleTheme} className="ml-4">
            {theme === "dark" ? <Sun /> : <Moon />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden flex items-center">
          <button onClick={toggleTheme} className="mr-4">
            {theme === "dark" ? <Sun /> : <Moon />}
          </button>
          <button onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
        </div>
      </div>

      {/* Mobile Menu Animate */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-background/95 border-t border-border overflow-hidden"
          >
            <div className="flex flex-col space-y-4 p-4">
              {navLinks.map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="hover:text-primary transition-colors"
                >
                  {link}
                </a>
              ))}

              {isSignedIn ? (
                <>
                  <a
                    href="/dashboard"
                    className="flex items-center px-4 py-2 rounded bg-[color:var(--primary)] text-[color:var(--primary-foreground)] hover:brightness-90 transition"
                  >
                    <User className="mr-2" /> {user?.firstName || "Account"}
                  </a>
                  <SignOutButton>
                    <button className="flex items-center px-4 py-2 rounded bg-destructive text-destructive-foreground hover:brightness-90 transition">
                      <LogOut className="mr-2" /> Logout
                    </button>
                  </SignOutButton>
                </>
              ) : (
                <a
                  href="/register"
                  className="px-4 py-2 rounded transition bg-[color:var(--primary)] text-[color:var(--primary-foreground)] hover:brightness-90"
                >
                  Join Now
                </a>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
