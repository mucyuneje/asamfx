-- AlterTable
ALTER TABLE `video` ADD COLUMN `difficulty` VARCHAR(191) NULL,
    ADD COLUMN `price` DOUBLE NULL,
    ADD COLUMN `subtitle` VARCHAR(191) NULL;
