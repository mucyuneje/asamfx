-- AlterTable
ALTER TABLE `payment` MODIFY `amount` DOUBLE NULL;
